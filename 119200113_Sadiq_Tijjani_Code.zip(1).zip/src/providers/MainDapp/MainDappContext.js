import React from "react";

const MainDappContext = React.createContext();

export default MainDappContext;
